package com.qimu.qiapicommon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QiApiCommonApplicationTests {

    @Test
    void contextLoads() {
    }

}
